class Recorder:

    def __init__(self):
        self.total = 0
        self.semi = 0
        self.invalid = 0
        self.apply_num = 0
